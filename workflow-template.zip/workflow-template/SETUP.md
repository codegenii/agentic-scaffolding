# Workflow template — setup

This is a language-agnostic, multi-agent TDD workflow harness for Claude Code. Copy it into an empty repo and it gives you: a strict spec-first TDD state machine, four worker agents with hard file-ownership boundaries, worktree-isolated parallel work, an immutable-spec registry, single-source project invariants, and a bounded process retrospective.

It carries **no domain logic and no language wiring** of its own. Everything stack-specific is a `${...}` variable resolved from `.claude/project.md`.

## Install

1. Copy the contents of this folder into the root of a fresh git repo (`git init` first if needed). Include the dotfiles: `.claude/`, `.gitignore`.
2. Make the scripts executable: `chmod +x scripts/*.sh`.
3. Open the repo in Claude Code and run **`/init-project`**. It interviews you (language, test/build/lint/format commands, file patterns, license, invariants) and fills in every placeholder, then deletes itself and this `SETUP.md`.
4. Authenticate the GitHub CLI (`gh auth login`) — the PR-review phase uses it.

After `/init-project`, start work:

- `/new-feature <slug>` — runs the full 8-phase TDD workflow for a new feature.
- `/new-chore <description>` — isolated worktree for non-feature work (refactors, docs, config).
- `/resume-feature <slug>` — resume an interrupted feature, phase detected from git history.
- `/retro` — bounded process retrospective, applies at most 3 small fixes.

## What's in here

```
.claude/
  project.md                 # the stack-config hub — every ${VAR} resolves here
  orchestrator.md            # the 8-phase TDD state machine
  orchestrator/
    sub-agent-contract.md
    phases/phase-1.md … phase-7.md (+ phase-4_5.md)
  agents/
    _conventions.md          # pointer index + review-time style baseline
    _conventions-reference.md # detail-on-demand (specs, tests, license)
    _task-preamble.md         # leaf-agent rules, inherited by every brief
    conventions/
      coding.md               # implementer conventions
      testing.md              # test-writer conventions
      invariants.md           # SINGLE authoritative list of project invariants
    context/
      implementer-context.md  # per-agent architecture card
      test-writer-context.md
    implementer.md            # writes non-test source
    test-writer.md            # writes test files
    spec-reviewer.md          # audits specs before code
    pr-reviewer.md            # reviews the diff, posts the PR verdict
  optimization/
    spec-sections-map.md      # which spec sections each phase passes to each agent
  commands/
    init-project.md           # one-time setup (self-deletes)
    new-feature.md  new-chore.md  resume-feature.md  retro.md
scripts/
  prune-worktrees.sh  setup-worktree.sh  sync-worktree-permissions.sh
docs/
  architecture.md  decisions.md  specs/README.md
CLAUDE.md
```

## The model in one paragraph

A feature is specified, the spec is reviewed and frozen, an interface skeleton is built, failing tests are written against it (red), dependencies are added, the implementation is driven until the tests pass (green), the diff is reviewed on a draft PR, and the PR is marked ready — for a **human** to merge. Each phase has objective entry/exit gates and an iteration cap; nothing is skipped or reordered. The driving session never writes code itself — it spawns `implementer` and `test-writer`, which can only touch their own file types. This is what keeps generated code honest: tests are written before implementation by a different agent that cannot edit the implementation, and the implementation is written by an agent that cannot edit the tests.

## Customizing

- **Commands and patterns** — all in `.claude/project.md`. Change them there, never in the phases.
- **Invariants** — add to `.claude/agents/conventions/invariants.md` only. It is the single source every agent loads. Never copy an invariant into a role file (the `/retro` command checks for that drift).
- **No GitHub?** Edit phase-6/phase-7 and `pr-reviewer.md` to review the local diff and stop at the branch instead of using `gh`.
- **Agent models** — set per agent in each definition's frontmatter `model:` field.
